#include "GROVE_SOUND.h"
#include "mbed.h"

GROVE_SOUND::GROVE_SOUND(PinName pin) : _pin(pin){
    sum = 0;
    average = 0;
}

float GROVE_SOUND::get_decibels(){
   
    float values[1000];
    for(int i=0;i<1000;i++){
        values[i] = _pin.read()* 3.3;
        wait(0.0001);
    }
 
    for(int j=0;j<1000;j++){
        sum += values[j];   
        }
    average = sum/1000;
    sum=0;
    decibels = average * 29;
    return decibels;
    }
