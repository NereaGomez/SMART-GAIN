/***************************************************
  This is a library for grove sound sensor

  Written by Nerea Gómez.
  
 ****************************************************/

#ifndef MBED_GROVE_SOUND_H
#define MBED_GROVE_SOUND_H
#include "mbed.h"

class GROVE_SOUND {
    public:
    
        GROVE_SOUND(PinName pin);
        float get_decibels();
      
    private:  
    
        AnalogIn _pin;
        float decibels;
        float values[1000];
        float sum;
        float average;
         
};
 
#endif
 