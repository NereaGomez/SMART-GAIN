#include "MQ7.h"
#include "mbed.h"

MQ7::MQ7(PinName pinA, PinName pinD) : _pinA(pinA), _pinD(pinD) {

     
}
int MQ7::get_CO_value(){
    float a = _pinA.read_u16();
    printf("%f\r\n",a);
    if(a<16384){
        return 0;
    }else if(a> 16383 && a<32768){
        return 1;
    }else if(a>32767 && a<49152){
        return 2;
    }else{
        return 3;
        }
            
}