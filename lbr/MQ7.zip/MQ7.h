/***************************************************
  This is a library for MQ7 gas sensor

  Written by Nerea Gómez.
  
 ****************************************************/

#ifndef MBED_MQ7_H
#define MBED_MQ7_H

 
#include "mbed.h"

class MQ7 {
    public:
        MQ7(PinName pinA, PinName pinD);
        int get_CO_value();
      
    private:  
        AnalogIn _pinA;
        DigitalIn _pinD;
        
};
 
#endif
 